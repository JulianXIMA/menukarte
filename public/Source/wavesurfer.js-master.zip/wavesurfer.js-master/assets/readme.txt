Logo is free to use with this project, link back to the official github page to support the project.
https://github.com/katspaugh/wavesurfer.js 

Available Logo Versions:
- svg text logo (black/white)
- svg full logo (black/white)
- svg symbol logo

- png text logo (black/white)
- png full logo (black/white)
- png symbol logo
